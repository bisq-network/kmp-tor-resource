@file:Suppress("SpellCheckingInspection")

package io.matthewnelson.kmp.tor.resource.compilation.lib.tor.internal

internal const val ENV_KEY_LIBTOR: String = "io_matthewnelson_kmp_tor_resource_compilation_lib_tor_LIBTOR"
internal const val ENV_KEY_LIBTOREXEC: String = "io_matthewnelson_kmp_tor_resource_compilation_exec_tor_LIBTOREXEC"
internal const val ENV_KEY_LIBTORJNI: String = "io_matthewnelson_kmp_tor_resource_noexec_tor_LIBTORJNI"

//@Throw(IllegalStateException::class)
@Suppress("NOTHING_TO_INLINE")
internal inline fun String.envKeyLibName(): String = when (this) {
    ENV_KEY_LIBTOR, ENV_KEY_LIBTOREXEC, ENV_KEY_LIBTORJNI -> substringAfterLast('_').lowercase() + ".so"
    else -> error("Unknown environment key >> $this")
}
