/*
 * Copyright (c) 2024 Matthew Nelson
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 **/
package io.matthewnelson.kmp.tor.resource.frameworks

import org.gradle.api.provider.Property

public abstract class KmpTorResourceFrameworksExtension internal constructor() {

    /**
     * Default: `false`
     *
     * Will extract tor framework(s) compiled with flag `--enable-gpl`.
     * */
    public abstract val torGPL: Property<Boolean>

    public companion object {
        public const val NAME: String = "kmpTorResourceFrameworks"
    }
}
