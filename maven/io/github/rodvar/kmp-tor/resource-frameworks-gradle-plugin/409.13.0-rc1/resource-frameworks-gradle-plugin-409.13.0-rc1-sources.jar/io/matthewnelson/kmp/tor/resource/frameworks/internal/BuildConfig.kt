package io.matthewnelson.kmp.tor.resource.frameworks.internal

internal const val HASH_IOS_LIBTOR: String = "23826512163797b1d1b5c48e37c2135ae3df90ff2d080d1d460e2bbe0c9c87b8"
internal const val HASH_IOS_LIBTOR_GPL: String = "be69f90d21935745a1f7de8689e92356dcda3de76e47430987e117e7a2799804"
