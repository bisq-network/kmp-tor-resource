package io.matthewnelson.kmp.tor.resource.frameworks.internal

internal const val HASH_IOS_LIBTOR: String = "c8385e5b5143e8fc8a3faa62d703597bf2640a5a08179f23d8ba08db7ccdf649"
internal const val HASH_IOS_LIBTOR_GPL: String = "93ef3de3fc11c819bd3eeb6daadad58cd6fd6100131a0199a86e60a24d6e9342"
